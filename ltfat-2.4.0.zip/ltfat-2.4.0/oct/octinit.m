if isoctave
  status=2;
else
  status=0;
end;


