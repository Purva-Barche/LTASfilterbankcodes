#define LTFAT_NAME(name) name ## _d
