#include <complex.h>
double ltfat_time();

void fillRand_d(double *in, int L);
void fillRand_s(float *in, int L);
void fillRand_cd(double _Complex *in, int L);
void fillRand_cs(float _Complex *in, int L);
