% LTFAT - Basic Fourier and DCT analysis.
%
%  Peter L. Søndergaard, 2008 - 2018.
%
%  Support routines
%    FFTINDEX       -  Index of positive and negative frequencies.
%    MODCENT        -  Centered modulo operation.
%    FLOOR23        -  Previous number with only 2,3 factors
%    FLOOR235       -  Previous number with only 2,3,5 factors
%    CEIL23         -  Next number with only 2,3 factors
%    CEIL235        -  Next number with only 2,3,5 factors
%    NEXTFASTFFT    -  Next efficient FFT size (2,3,5,7).
%  
%  Basic Fourier analysis
%    DFT            -  Unitary discrete Fourier transform.
%    IDFT           -  Inverse of |dft|.
%    FFTREAL        -  FFT for real valued signals.
%    IFFTREAL       -  Inverse of |fftreal|.
%    GGA            -  Generalized Goertzel Algorithm.
%    CHIRPZT        -  Chirped Z-transform.
%    FFTGRAM	    -  Plot energy of FFT.
%    PLOTFFT        -  Plot FFT coefficients.
%    PLOTFFTREAL    -  Plot |fftreal| coefficients.
%
%  Simple operations on periodic functions
%    INVOLUTE       -  Involution.
%    PEVEN          -  Even part of periodic function.
%    PODD           -  Odd part of periodic function.
%    PCONV          -  Periodic convolution.
%    PXCORR         -  Periodic crosscorrelation.
%    LCONV          -  Linear convolution.
%    LXCORR	    -  Linear crosscorrelation. 
%    ISEVENFUNCTION -  Test if function is even.
%    MIDDLEPAD      -  Cut or extend even function.
%
%  Periodic functions
%    EXPWAVE        -  Complex exponential wave.
%    PCHIRP         -  Periodic chirp.
%    PGAUSS         -  Periodic Gaussian.
%    PSECH          -  Periodic SECH.
%    PBSPLINE       -  Periodic B-splines.
%    SHAH           -  Shah distribution.
%    PHEAVISIDE     -  Periodic Heaviside function.
%    PRECT          -  Periodic rectangle function.
%    PSINC          -  Periodic sinc function.
%    PTPFUN         -  Periodic totally positive function of finite type.
%    PEBFUN         -  Periodic EB spline. 
%
%  Specialized dual windows
%    PTPFUNDUAL     -  Dual window for |PTPFUN|
%    PEBFUNDUAL     -  Dual window for |PEBFUN|
%
%  Hermite functions and fractional Fourier transforms
%    PHERM          -  Periodic Hermite functions.
%    HERMBASIS      -  Orthonormal basis of Hermite functions.    
%    DFRACFT        -  Discrete Fractional Fourier transform
%    FFRACFT        -  Fast Fractional Fourier transform
%
%  Approximation of continuous functions
%    FFTRESAMPLE    -  Fourier interpolation.
%    DCTRESAMPLE    -  Cosine interpolation.
%    PDERIV         -  Derivative of periodic function.
%    FFTANALYTIC    -  Analytic representation of a function.
%
%  Cosine and Sine transforms.
%    DCTI           -  Discrete cosine transform type I
%    DCTII          -  Discrete cosine transform type II
%    DCTIII         -  Discrete cosine transform type III
%    DCTIV          -  Discrete cosine transform type IV
%    DSTI           -  Discrete sine transform type I
%    DSTII          -  Discrete sine transform type II
%    DSTIII         -  Discrete sine transform type III
%    DSTIV          -  Discrete sine transform type IV
%
%  For help, bug reports, suggestions etc. please visit 
%  http://github.com/ltfat/ltfat/issues

