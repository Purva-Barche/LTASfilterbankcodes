function definput=arg_plotfilterbank(definput)

  definput.keyvals.fc=[];
  definput.keyvals.ntickpos=10;
  definput.keyvals.tick=[];
  definput.groups.audtick={'tick',[0,100,250,500,1000,2000,4000,8000,16000,32000]};


