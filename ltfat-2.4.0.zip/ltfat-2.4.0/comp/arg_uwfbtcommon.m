function definput = arg_uwfbtcommon(definput)

% Filter scaling
definput.flags.scaling={'sqrt','scale','noscale','scaling_notset'};
