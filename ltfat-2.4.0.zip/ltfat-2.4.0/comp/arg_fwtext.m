function definput = arg_fwtext(definput)

%definput.flags.ext=  {'per','zpd','sym','symw','asym','asymw','ppd','sp0'};
definput.flags.ext = {'per','zero','even','odd'};
