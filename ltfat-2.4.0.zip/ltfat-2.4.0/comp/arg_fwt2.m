function definput = arg_fwt2(definput)

definput.flags.type2d = {'standard','tensor'};
