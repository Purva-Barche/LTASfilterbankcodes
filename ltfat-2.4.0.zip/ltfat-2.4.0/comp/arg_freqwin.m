function definput=arg_freqwin(definput)
  
  definput.flags.wintype={ 'gammatone', 'gauss' ,'butterworth'};
  

