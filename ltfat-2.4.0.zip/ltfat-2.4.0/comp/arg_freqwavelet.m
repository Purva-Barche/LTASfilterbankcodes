function definput=arg_freqwavelet(definput)
  
  definput.flags.wavelettype={ 'cauchy', 'morse'};
  

