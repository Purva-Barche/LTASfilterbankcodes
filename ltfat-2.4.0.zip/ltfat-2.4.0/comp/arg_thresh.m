function definput=arg_thresh(definput)
  
  definput.flags.iofun={'hard','soft','wiener'};
  definput.flags.outclass={'full','sparse'};


