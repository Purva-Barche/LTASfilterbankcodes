function definput = arg_filterbankdual(definput)

definput.flags.painless = {'none','forcepainless'};
definput.keyvals.L = [];
