function definput = arg_fwtcommon(definput)


%definput.flags.ansy = {'syn','ana'};
definput.keyvals.a = [];
