function definput=arg_ltfattranslate(definput)

  definput.keyvals.frequency='Frequency';
  definput.keyvals.time='Time';
  definput.keyvals.samples='samples';
  definput.keyvals.normalized='normalized';
  definput.keyvals.magnitude='Magnitude';


