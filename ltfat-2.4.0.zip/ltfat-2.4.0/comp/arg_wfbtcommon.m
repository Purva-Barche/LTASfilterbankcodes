function definput = arg_wfbtcommon(definput)

% definput.keyvals.J = 1;
% definput.flags.treetype = {'full','dwt'};
% Frequency vs. natral ordering of the output subbands
definput.flags.forder = {'freq','nat'};
