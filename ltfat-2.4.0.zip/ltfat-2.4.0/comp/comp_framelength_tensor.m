function L=comp_framelength_tensor(F,Ls);
%COMP_FRAMELENGTH_TENSOR  Helper function for the Tensor frame
%  
error(['For the tensor product frame, call framelength for the ', ...
       'individual subframes']);
