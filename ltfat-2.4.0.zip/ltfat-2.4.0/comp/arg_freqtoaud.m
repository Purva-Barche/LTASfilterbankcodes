function definput=arg_freqtoaud(definput)
  
  definput.flags.audscale={'erb','mel','mel1000','bark','erb83','freq','log10','semitone'};


