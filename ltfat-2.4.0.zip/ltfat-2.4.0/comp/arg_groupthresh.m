function definput=arg_groupthresh(definput)

  definput.flags.grouptype={'group','elite'};


