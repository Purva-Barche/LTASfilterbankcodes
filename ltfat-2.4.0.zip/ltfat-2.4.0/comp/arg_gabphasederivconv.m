function definput=arg_gabphasederivconv(definput)
definput.flags.phaseconv = {'freqinv','timeinv','symphase','relative'};
  

